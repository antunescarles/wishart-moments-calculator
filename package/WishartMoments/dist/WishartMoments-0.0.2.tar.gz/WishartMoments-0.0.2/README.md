# Firs version of the Wishart Moments package

This is a fist version.