# Wishart Moments Package
This is a package for computing the symbolic expressions of all the invariant Wishart moments of a given order. 