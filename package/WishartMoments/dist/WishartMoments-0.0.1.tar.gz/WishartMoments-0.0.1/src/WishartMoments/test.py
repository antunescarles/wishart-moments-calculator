from sage.all import *
def foo(k):
    return Partitions(k).list()